import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ClothService {

  constructor(private http:HttpClient) { }

  getCloths()
  {
    return this.http.get("https://localhost:44300/api/BuyCloth");
  }
}
